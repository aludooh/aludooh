$('#slider').slick({
  dots: true,
  infinite: true,
  speed: 400,
  slidesToShow: 1,
  adaptiveHeight: true,
  autoplay: true,
  autoplaySpeed: 5000
});
